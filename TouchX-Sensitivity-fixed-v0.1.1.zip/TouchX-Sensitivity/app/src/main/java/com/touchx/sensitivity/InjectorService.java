package com.touchx.sensitivity;

import android.os.IBinder;
import android.os.Process;
import android.view.InputEvent;
import android.view.MotionEvent;
import java.lang.reflect.Method;

/** Runs as Shizuku's shell UID (2000), not as an ordinary Android Service. */
public final class InjectorService extends IInjector.Stub {
    private Object inputManager;
    private Method injectTarget;
    private String error = "Not initialized";

    public InjectorService() {
        try {
            if (Process.myUid() != 2000) {
                error = "Not running as adb shell UID 2000";
                return;
            }
            Class<?> sm = Class.forName("android.os.ServiceManager");
            IBinder binder = (IBinder) sm.getMethod("getService", String.class)
                    .invoke(null, "input");
            if (binder == null) throw new IllegalStateException("input service not found");
            Class<?> stub = Class.forName("android.hardware.input.IInputManager$Stub");
            Object manager = stub.getMethod("asInterface", IBinder.class).invoke(null, binder);
            Method target = manager.getClass().getMethod("injectInputEventToTarget",
                    InputEvent.class, int.class, int.class);
            inputManager = manager;
            injectTarget = target;
            error = "OK";
        } catch (Throwable failure) { error = failure.toString(); }
    }

    @Override public boolean available() { return injectTarget != null; }
    @Override public String lastError() { return error; }

    @Override public synchronized boolean inject(MotionEvent event, int targetUid) {
        if (injectTarget == null || targetUid < 10000 || event == null) return false;
        try {
            // 0 = asynchronous injection. No untargeted fallback: prevents touching other apps.
            Object result = injectTarget.invoke(inputManager, event, 0, targetUid);
            boolean ok = Boolean.TRUE.equals(result);
            if (!ok) error = "injectInputEventToTarget returned false";
            return ok;
        } catch (Throwable failure) {
            error = "Injection error: " + failure;
            return false;
        }
    }
    @Override public void destroy() { System.exit(0); }
}
