package com.touchx.sensitivity;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.graphics.Point;
import android.hardware.display.DisplayManager;
import android.view.Display;
import android.view.InputDevice;
import android.view.MotionEvent;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Toast;

import java.util.concurrent.atomic.AtomicInteger;

/** Android 14+ experimental touch intercept / reinjection. Never intercepts globally by default. */
public final class TouchAccessibilityService extends AccessibilityService {
    static volatile TouchAccessibilityService running;
    private Profiles profiles;
    private final Handler main = new Handler(Looper.getMainLooper());
    private HandlerThread senderThread;
    private Handler sender;
    private final AtomicInteger pending = new AtomicInteger();
    private final TouchTransform transform = new TouchTransform();
    private String foreground = "";
    private int targetUid = -1;
    private boolean intercepting;
    private int failures;
    private int volumeTaps;
    private long volumeFirstTap;
    private static final int NOTIFICATION_ID = 44;
    private static final String CHANNEL = "touchx_status";

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        running = this;
        profiles = new Profiles(this);
        senderThread = new HandlerThread("TouchX-InjectorThread");
        senderThread.start();
        sender = new Handler(senderThread.getLooper());
        ShizukuBridge.initialize(this);
        ShizukuBridge.bindIfPermitted();
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(
                new NotificationChannel(CHANNEL, "TouchX active", NotificationManager.IMPORTANCE_LOW));
        updateForeground();
        refreshCapture();
        main.post(watchdog);
    }

    private final Runnable watchdog = new Runnable() {
        @Override public void run() {
            if (running != TouchAccessibilityService.this) return;
            updateForeground();
            refreshCapture();
            main.postDelayed(this, 1000L);
        }
    };
    static void refreshRunningService() {
        TouchAccessibilityService service = running;
        if (service != null) service.main.post(service::refreshCapture);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
                event.getEventType() == AccessibilityEvent.TYPE_WINDOWS_CHANGED) {
            if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
                    event.getPackageName() != null) updatePackage(event.getPackageName().toString());
            updateForeground();
            refreshCapture();
        }
    }
    private void updateForeground() {
        try {
            android.view.accessibility.AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root != null) {
                CharSequence name = root.getPackageName();
                if (name != null && name.length() > 0) updatePackage(name.toString());
                root.recycle();
            }
        } catch (Throwable ignored) { }
    }
    private void updatePackage(String pkg) {
        if (pkg.equals(foreground)) return;
        foreground = pkg;
        transform.reset();
        failures = 0;
        try { targetUid = getPackageManager().getApplicationInfo(pkg, 0).uid; }
        catch (PackageManager.NameNotFoundException ex) { targetUid = -1; }
    }
    private void refreshCapture() {
        if (profiles == null) return;
        boolean want = profiles.isEnabled() && targetUid >= 10000 &&
                profiles.selected(foreground) && ShizukuBridge.ready();
        if (want == intercepting) return;
        intercepting = want;
        transform.reset();
        try {
            AccessibilityServiceInfo info = getServiceInfo();
            if (info != null) {
                info.setMotionEventSources(want ? InputDevice.SOURCE_TOUCHSCREEN : 0);
                setServiceInfo(info);
            } else intercepting = false;
        } catch (Throwable ex) {
            intercepting = false;
            profiles.setEnabled(false);
        }
        updateNotification();
    }
    @Override public void onMotionEvent(MotionEvent original) {
        if (!intercepting || (original.getSource() & InputDevice.SOURCE_TOUCHSCREEN) != InputDevice.SOURCE_TOUCHSCREEN)
            return;
        // Synthetic injected events use virtual device (-1); never amplify them again.
        if (original.getDeviceId() < 0) return;
        if (!ShizukuBridge.ready() || targetUid < 10000 || !profiles.selected(foreground)) {
            emergencyStop("Shizuku disconnected");
            return;
        }
        int action = original.getActionMasked();
        // Bound backlog; never drop DOWN/UP so input lifecycle remains consistent.
        if (action == MotionEvent.ACTION_MOVE && pending.get() > 2) return;
        DisplayManager displayManager = (DisplayManager) getSystemService(DISPLAY_SERVICE);
        Display display = displayManager == null ? null : displayManager.getDisplay(Display.DEFAULT_DISPLAY);
        if (display == null) { emergencyStop("Display unavailable"); return; }
        Point size = new Point();
        display.getRealSize(size);
        Profiles.Config config = profiles.config(foreground);
        final MotionEvent out = transform.scale(original, config.x, config.y,
                size.x, size.y);
        final int destinationUid = targetUid;
        pending.incrementAndGet();
        boolean queued = sender.post(() -> {
            try {
                boolean result = ShizukuBridge.inject(out, destinationUid);
                main.post(() -> {
                    if (!result) {
                        if (++failures >= 2) emergencyStop("Touch injection failed");
                    } else {
                        failures = 0;
                    }
                });
            } catch (Throwable failure) {
                main.post(() -> emergencyStop("Injection crashed"));
            } finally {
                out.recycle();
                pending.decrementAndGet();
            }
        });
        if (!queued) {
            out.recycle();
            pending.decrementAndGet();
            emergencyStop("Injection thread unavailable");
        }
    }
    private void emergencyStop(String why) {
        if (profiles != null) profiles.setEnabled(false);
        if (intercepting) {
            // setMotionEventSources(0) first, even if notification cannot be posted.
            intercepting = false;
            try {
                AccessibilityServiceInfo info = getServiceInfo();
                info.setMotionEventSources(0);
                setServiceInfo(info);
            } catch (Throwable ignored) { }
        }
        transform.reset();
        updateNotification();
        Toast.makeText(this, "TouchX выключен: " + why, Toast.LENGTH_LONG).show();
    }
    private void updateNotification() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (!intercepting) { manager.cancel(NOTIFICATION_ID); return; }
        Intent stopIntent = new Intent(this, StopReceiver.class);
        PendingIntent stop = PendingIntent.getBroadcast(this, 1, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification note = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_menu_close_clear_cancel)
                .setContentTitle("TouchX: усиление касаний активно")
                .setContentText(foreground + " • нажми СТОП при проблемах")
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_delete, "СТОП", stop).build())
                .build();
        manager.notify(NOTIFICATION_ID, note);
    }
    static void stopNow() {
        TouchAccessibilityService service = running;
        if (service != null) service.main.post(() -> service.emergencyStop("Отключено пользователем"));
    }
    @Override protected boolean onKeyEvent(KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_VOLUME_DOWN &&
                event.getAction() == KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0) {
            long now = SystemClock.uptimeMillis();
            if (now - volumeFirstTap > 2000L) { volumeFirstTap = now; volumeTaps = 0; }
            if (++volumeTaps >= 3) {
                volumeTaps = 0;
                emergencyStop("3 нажатия громкости вниз");
            }
        }
        return false; // Do not steal volume buttons from Android.
    }
    @Override public void onInterrupt() { }
    @Override public void onDestroy() {
        running = null;
        main.removeCallbacks(watchdog);
        intercepting = false;
        if (senderThread != null) senderThread.quitSafely();
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).cancel(NOTIFICATION_ID);
        super.onDestroy();
    }
}
